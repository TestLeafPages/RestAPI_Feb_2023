package validateschema;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateIncidentSchemaValidation_Failure {

	
	
	@Test
	public void validateSchcema() {
		

		RestAssured.baseURI="https://dev140572.service-now.com/api/now/table/";

		//Authentication

		RestAssured.authentication=RestAssured.basic("admin", "P-qQ7@umSYz8");

		//Create Request body


		RequestSpecification inputRequest = RestAssured.given().
				contentType("application/json")
				.queryParam("sysparm_fields", "short_description")
				
				.when().body("{\r\n"
						+ "    \"description\": \"Incident via file body\",\r\n"
						+ "    \"short_description\": \"Test description\"\r\n"
						+ "}");

		// Initiate the Request
		Response response = inputRequest.post("incident");
		
		File schemaFile=new File("./src/test/resources/Validateschema.json");
		
		response.then().assertThat().body(JsonSchemaValidator.matchesJsonSchema(schemaFile));
		
		
		
		
		
	}
}
