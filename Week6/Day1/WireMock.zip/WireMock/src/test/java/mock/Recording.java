package mock;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Recording {
	
	
	@Test
	public void record() {
		
		
		//Enter the Endpoint
		RestAssured.baseURI="http://localhost/api/now/table/";
		
		// Give Authorization
		
		RestAssured.authentication=RestAssured.basic("admin", "P-qQ7@umSYz8");
		
		// Specify the header for content type and Add the request body --Form the request
		
		RequestSpecification inputRequest = RestAssured.given();
		
		// Send the Request
		
		Response response = inputRequest.get("incident");
	
		
		// prints the Response in console
		response.prettyPrint();
	}

}
