package mock;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class DynamicTemplating {
	
	
	
	
	//java -jar wiremock-jre8-standalone-2.35.0.jar --global-response-templating
	
	@Test
	public void templates() {
		
		RestAssured.baseURI="http://localhost/testleaf/training/course";
		Response response = RestAssured.given()
		.queryParam("course_name", "Devops")
		.queryParam("type", "offline")
		.get();
		
		response.prettyPrint();
	}

}
