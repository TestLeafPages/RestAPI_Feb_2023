package mock;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class TestStub {

	@Test
	public void stub() {
		
		RestAssured.baseURI="http://localhost/api/now/table/";
	//	RestAssured.baseURI="https://dev140572.service-now.com/api/now/table/";
		RestAssured.authentication=RestAssured.basic("admin", "P-qQ7@umSYz8");
		
		// Specify the header for content type and Add the request body --Form the request
		
		RequestSpecification inputRequest = RestAssured.given().contentType("application/json").body("{\r\n"
				+ "    \"description\": \"hi\",\r\n"
				+ "    \"short_description\": \"Test description\"\r\n"
				+ "}");
		
		// Send the Request
		
		Response response = inputRequest.post("incident");
	
		
		// prints the Response in console
		response.prettyPrint();
		System.out.println(response.getStatusCode());
		
	}
}
