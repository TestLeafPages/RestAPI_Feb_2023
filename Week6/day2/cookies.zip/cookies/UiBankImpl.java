package cookies;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class UiBankImpl {
	
	public static String id;
	@BeforeMethod
	public void setUp() {
		
		RestAssured.baseURI="https://uibank-api.azurewebsites.net/api/";
		
		RequestSpecification inputRequest = RestAssured.given().
		contentType("application/json")
		.body("{\r\n"
				+ "    \"username\": \"FebApiuser\",\r\n"
				+ "    \"password\": \"Eagle@123\"\r\n"
				+ "}");
		Response response = inputRequest.post("users/login");
		 id = response.jsonPath().get("id");
		System.out.println(id);
	}
	
	@Test
	public void createAccount() {
		
		 RequestSpecification inputReq = RestAssured.given().
		contentType("application/json")
		.header("authorization",id)
		.body("{\r\n"
				+ "    \"friendlyName\": \"Test133\",\r\n"
				+ "    \"type\": \"savings\",\r\n"
				+ "    \"userId\": \"64290731ba9f8a0047adacfc\",\r\n"
				+ "    \"balance\": 100,\r\n"
				+ "    \"accountNumber\": 23767121\r\n"
				+ "}");
		 Response response = inputReq.post("accounts");
		 response.prettyPrint();
	}

}
