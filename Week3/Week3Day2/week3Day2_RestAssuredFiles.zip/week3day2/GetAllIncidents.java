package week3day2;

import java.util.List;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetAllIncidents {

	@Test
	public void getIncidents() {
		
	//Specify the endpoint
		
		RestAssured.baseURI="https://dev140572.service-now.com/api/now/table/";
		
		//Authentication
		
		RestAssured.authentication=RestAssured.basic("admin", "P-qQ7@umSYz8");
		
		//Request Body
		RequestSpecification inputRequest = RestAssured.
		given().
		queryParam("sysparm_fields", "sys_id,number,sys_updated_by") ;//Single Query Parameter
		
		//Initiate the Request
		Response response = inputRequest.get("incident");
		
		//Traverse and get Multiple values
		
		List<String> allIncidents = response.jsonPath().getList("result.sys_id");
		
		int size = allIncidents.size();
		System.out.println(allIncidents);
		System.out.println("Total Incidents"+size);
		
		
		int statusCode = response.getStatusCode();
		 System.out.println(statusCode);
		 String statusLine = response.getStatusLine();
		 System.out.println(statusLine);
		 response.prettyPrint();
		 
		
	}
}
