package week3day2;



import java.io.File;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateIncidentWithFileBody {
	
	@Test
	public void createIncident() {
		
		//Specify the endpoint
		
		RestAssured.baseURI="https://dev140572.service-now.com/api/now/table/";
		
		//Authentication
		
		RestAssured.authentication=RestAssured.basic("admin", "P-qQ7@umSYz8");
		
		//Create Request body
		
		File file =new File ("./data/CreateIncident.json");
		
	RequestSpecification inputRequest = RestAssured.given().
			contentType("application/json").when().body(file);
	
	// Initiate the Request
	Response response = inputRequest.post("incident");
	
	//Extract the value of Sys_id from the response

	
	String sys_id = response.jsonPath().get("result.sys_id");
	
	System.out.println(sys_id);
	
	//Print the response
	response.prettyPrint();
		
	}

}
