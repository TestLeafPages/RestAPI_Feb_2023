package week3day2;

import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetAllIncidentsWithMultipleQP {

	@Test
	public void getIncidents() {
		
	//Specify the endpoint
		
		RestAssured.baseURI="https://dev140572.service-now.com/api/now/table/";
		
		//Authentication
		
		RestAssured.authentication=RestAssured.basic("admin", "P-qQ7@umSYz8");
		
		Map<String,String> queryParams=new HashMap<String,String>();
		queryParams.put("sysparm_limit","1");
		queryParams.put("sysparm_fields", "sys_id,number,sys_updated_by");
		
		
		//Request Body
		RequestSpecification inputRequest = RestAssured.
		given().
		queryParams(queryParams);
		//queryParam("sysparm_fields", "sys_id,number,sys_updated_by") //Single Query Parameter
		//.queryParam("sysparm_limit", "1");
		
		//Initiate the Request
		Response response = inputRequest.get("incident");
		 response.prettyPrint();
		
	}
}
