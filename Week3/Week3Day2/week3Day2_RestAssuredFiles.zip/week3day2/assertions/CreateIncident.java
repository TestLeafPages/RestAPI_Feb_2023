package week3day2.assertions;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class CreateIncident {
    
	@Test
	public void incident() {


		//Specify the endpoint

		RestAssured.baseURI="https://dev140572.service-now.com/api/now/table/";

		//Authentication

		RestAssured.authentication=RestAssured.basic("admin", "P-qQ7@umSYz8");

		//Create Request body

		File file =new File ("./data/CreateIncident.json");

		RequestSpecification inputRequest = RestAssured.given().
				contentType("application/json").when().body(file);

		// Initiate the Request
		Response response = inputRequest.post("incident");
		
		//Validate response
		int actualStatusCode = response.getStatusCode();
		if(actualStatusCode==200)
		{
			System.out.println("Testcase Passed");
		}
		
		else {
			System.out.println("TestCase failed");
		}
	}

}
