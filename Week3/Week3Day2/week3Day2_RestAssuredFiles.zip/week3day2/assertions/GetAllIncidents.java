package week3day2.assertions;

import java.util.List;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetAllIncidents {

	@Test
	public void getIncidents() {
		
	//Specify the endpoint
		
		RestAssured.baseURI="https://dev140572.service-now.com/api/now/table/";
		
		//Authentication
		
		RestAssured.authentication=RestAssured.basic("admin", "P-qQ7@umSYz8");
		
		//Request Body
		RequestSpecification inputRequest = RestAssured.
		given().
		queryParam("sysparm_fields", "sys_id,number,sys_updated_by") ;//Single Query Parameter
		
		//Initiate the Request
		Response response = inputRequest.get("incident");
		
		//response.prettyPrint();
		String statusLine = response.getStatusLine();
		System.out.println(statusLine);
        // validate response --Assert the status line  //HTTP/1.1 200 OK
		response.then().assertThat().statusLine("HTTP/1.1 200 OK");
		response.then().assertThat().statusLine(Matchers.containsString("HTTP"));
		//INC0010022
		response.then().assertThat().body("result.number",Matchers.hasItem("INC00100221"));
		 
		
	}
}
