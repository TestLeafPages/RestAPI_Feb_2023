package week3day2;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class DeleteIncident {

	@Test
	public void delete() {
		
		//Specify the endpoint

		RestAssured.baseURI="https://dev140572.service-now.com/api/now/table/";

		//Authentication

		RestAssured.authentication=RestAssured.basic("admin", "P-qQ7@umSYz8");
		
		
		//Form Request
		
		RequestSpecification inputRequest = RestAssured.given();
		
		Response response = RestAssured.delete("incident/1c741bd70b2322007518478d83673af3");
		//Response response = inputRequest.delete("incident/15e0665587e92510fe8655383cbb350e");
		
		//Extract status line from delete
		String statusLine = response.getStatusLine();
		
		System.out.println(statusLine); //HTTP/1.1 204 No Content
		
		
	}
}
