package week3day2;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class UpdateIncident {

	@Test
	public void update() {

		//Specify the endpoint

		RestAssured.baseURI="https://dev140572.service-now.com/api/now/table/";

		//Authentication

		RestAssured.authentication=RestAssured.basic("admin", "P-qQ7@umSYz8");
		
		File file=new File("./data/UpdateIncident.json");
		
		//Request Body
		RequestSpecification inputRequest = RestAssured.given().
				contentType("application/json").when().body(file);
		
		//Initiate the Request
		Response response = inputRequest.put("incident/1c741bd70b2322007518478d83673af3");
		
		//Print the response 
		response.prettyPrint();
		

	}
}
