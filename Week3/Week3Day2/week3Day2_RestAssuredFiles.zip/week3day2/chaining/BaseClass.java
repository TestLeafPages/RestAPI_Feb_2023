package week3day2.chaining;

import org.testng.annotations.BeforeMethod;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class BaseClass {

	public static RequestSpecification inputRequest;
	public static Response response;
	public static String sys_ID;
	
	@BeforeMethod
	public void setUp() {
		
		//Specify the endpoint

				RestAssured.baseURI="https://dev140572.service-now.com/api/now/table/";

				//Authentication

				RestAssured.authentication=RestAssured.basic("admin", "P-qQ7@umSYz8");
	}
}
