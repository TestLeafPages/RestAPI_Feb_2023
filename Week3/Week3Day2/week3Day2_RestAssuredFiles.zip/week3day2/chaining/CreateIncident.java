package week3day2.chaining;

import java.io.File;

import org.testng.annotations.Test;

import io.restassured.RestAssured;


public class CreateIncident extends BaseClass{
	@Test
	public void incident() {
		
		File file =new File ("./data/CreateIncident.json");
		
		 inputRequest = RestAssured.given().
				contentType("application/json").when().body(file);
		 response = inputRequest.post("incident");
		 
		 sys_ID = response.jsonPath().get("result.sys_id");
		 System.out.println("Sysid from create Incident"+sys_ID);
		 
		 response.then().assertThat().statusCode(201);
	}
	

}
