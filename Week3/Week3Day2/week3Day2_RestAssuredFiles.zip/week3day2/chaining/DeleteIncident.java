package week3day2.chaining;

import org.testng.annotations.Test;

import io.restassured.RestAssured;


public class DeleteIncident extends BaseClass {
	
	@Test(dependsOnMethods = "week3day2.chaining.UpdateIncident.update")
	public void delete() {
		
		
		 response = RestAssured.delete("incident/"+sys_ID);
		
		
		//Extract status line from delete
		String statusLine = response.getStatusLine();
		System.out.println("Statusline for Delete"+statusLine);
		
	}

}
