package week3day2.chaining;

import java.io.File;

import org.testng.annotations.Test;
import io.restassured.RestAssured;
public class UpdateIncident extends BaseClass {
	
	@Test(dependsOnMethods = "week3day2.chaining.CreateIncident.incident")  //packagename.classname.methodname
	public void update() {
		
	File file=new File("./data/UpdateIncident.json");
		
		//Request Body
		 inputRequest = RestAssured.given().
				contentType("application/json").when().body(file);
		
		//Initiate the Request
		 response = inputRequest.put("incident/"+sys_ID);
		 
		 int statusCode = response.getStatusCode();
		 
		 System.out.println(statusCode);
	}

}
