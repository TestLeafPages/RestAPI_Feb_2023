package jira;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Basics {
	
	@Test
	public void createIssue() {
		
		//Enter the Endpoint
				RestAssured.baseURI="https://testjirafeb2023.atlassian.net/rest/api/2/";
				
				// Give Authorization
				
				RestAssured.authentication=RestAssured.preemptive().basic("Feb2023restAPI@gmail.com", "ATATT3xFfGF0HaxeACZxbPqcC_hGbAGvR1nDfxlvTKLwUBsumHNbeLmVtRcSghFRFXxtytrC_a1EVOORE2cZbzTHCRcjpWFaQeTBxrm89U9Z1k8yqoCxDhv82ZbVxe-yvGYxPAgzZjKKnTA9r8evGONh69MnaDJ-nJVt7WKikeyrNVKCk6W1Zog=440F541C");
				
				// Specify the header for content type and Add the request body --Form the request
				
				RequestSpecification inputRequest = RestAssured.given().contentType("application/json").body("{\r\n"
						+ "    \"fields\": {\r\n"
						+ "        \"project\": {\r\n"
						+ "            \"key\": \"TS\"\r\n"
						+ "        },\r\n"
						+ "        \"summary\": \"create issue in Test project\",\r\n"
						+ "        \"description\": \"Creating of an issue using project keys and issue type names using the REST API\",\r\n"
						+ "        \"issuetype\": {\r\n"
						+ "            \"name\": \"Bug\"\r\n"
						+ "        }\r\n"
						+ "    }\r\n"
						+ "}");
				
				// Send the Request
				
				Response response = inputRequest.post("issue");
			
				
				// prints the Response in console
				response.prettyPrint();
	}

}
